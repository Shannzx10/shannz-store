const express = require('express');
const router = express.Router();
const path = require('path');

// Rute untuk halaman utama
router.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, '..', 'views', 'index.html'));
});

// Rute untuk halaman produk
router.get('/product', (req, res) => {
    res.sendFile(path.join(__dirname, '..', 'views', 'product.html'));
});

// Rute untuk halaman about
router.get('/about', (req, res) => {
    res.sendFile(path.join(__dirname, '..', 'views', 'about.html'));
});

// Rute untuk halaman kontak
router.get('/contact', (req, res) => {
    res.sendFile(path.join(__dirname, '..', 'views', 'contact.html'));
});

module.exports = router;